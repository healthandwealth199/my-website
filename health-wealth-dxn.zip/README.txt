هذه الحزمة تحتوي على موقع جاهز مكون من صفحتين (index.html و products.html) مع ملفات CSS وJS ومجلد صور (placeholders).
الصور داخل assets/images هي صور مؤقتة (placeholders). يفضل استبدالها بصور مجانية تجارية من مواقع مثل: Unsplash, Pexels أو Pixabay.
لرفع الحزمة إلى GitHub:
1. فك الضغط عن الملف health-wealth-dxn.zip
2. افتح مستودعك في GitHub
3. Add file -> Upload files -> حدد كل الملفات داخل مجلد health-wealth-dxn واضغط Commit
4. تفعيل GitHub Pages من Settings -> Pages -> Branch: main, Folder: / (root)
